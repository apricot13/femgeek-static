
Thank you for downloading the Brightness Lightroom Preset from www.femgeek.co.uk!

You may use this preset for commercial work as long as you credit me.


----------------------------------------------------------------------------------------------


This work is licensed under the Creative Commons Attribution-NoDerivs 3.0 Unported License. 

To view a copy of this license, visit http://creativecommons.org/licenses/by-nd/3.0/.